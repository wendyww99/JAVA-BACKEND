package service;

import dao.StudentDao;
import model.Student;

import java.util.Map;
import java.util.Optional;

public class StudentService {
    private final StudentDao studentDao;

    public StudentService(StudentDao studentDao) {
        this.studentDao = studentDao;
    }

    public void addStudent(Student student) {
        studentDao.addStudent(student);
    }

    public Optional<Student> getStudent(String id) {
        return studentDao.getStudent(id);
    }

    public Map<String, Student> getAllStudents() {
        return studentDao.getAllStudents();
    }

    public void deleteStudent(String id) {
        studentDao.deleteStudent(id);
    }
}
