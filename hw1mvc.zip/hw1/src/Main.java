import controller.StudentController;
import dao.StudentDao;
import model.Student;
import service.StudentService;

import java.util.Map;
import java.util.Optional;

public class Main {
    public static void main(String[] args) {
        StudentDao studentDao = new StudentDao();
        StudentService studentService = new StudentService(studentDao);
        StudentController studentController = new StudentController(studentService);

        // Create two new Students: Amy and Tom
        studentController.createStudent("1", "Amy", 22, "456 Elm St");
        studentController.createStudent("2", "Tom", 24, "789 Oak St");

        // Get and print each Student by ID
        Optional<Student> amy = studentController.getStudent("1");
        amy.ifPresent(System.out::println);

        Optional<Student> tom = studentController.getStudent("2");
        tom.ifPresent(System.out::println);

        // Get and print all Students
        Map<String, Student> allStudents = studentController.getAllStudents();
        allStudents.values().forEach(System.out::println);

        // Delete Student Amy
        studentController.deleteStudent("1");

        // Get and print all Students after deleting Amy
        Map<String, Student> remainingStudents = studentController.getAllStudents();
        remainingStudents.values().forEach(System.out::println);
    }
}

