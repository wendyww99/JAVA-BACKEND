package dao;

import model.Student;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class StudentDao {
    private final Map<String, Student> studentDatabase = new HashMap<>();

    public void addStudent(Student student) {
        studentDatabase.put(student.getId(), student);
    }

    public Optional<Student> getStudent(String id) {
        return Optional.ofNullable(studentDatabase.get(id));
    }

    public Map<String, Student> getAllStudents() {
        return new HashMap<>(studentDatabase);
    }

    public void deleteStudent(String id) {
        studentDatabase.remove(id);
    }
}

