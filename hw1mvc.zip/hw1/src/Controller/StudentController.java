package controller;

import model.Student;
import service.StudentService;

import java.util.Map;
import java.util.Optional;

public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    public void createStudent(String id, String name, int age, String address) {
        Student student = new Student(id, name, age, address);
        studentService.addStudent(student);
    }

    public Optional<Student> getStudent(String id) {
        return studentService.getStudent(id);
    }

    public Map<String, Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    public void deleteStudent(String id) {
        studentService.deleteStudent(id);
    }
}

