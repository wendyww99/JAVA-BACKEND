package com.example.student_management.Infrastructure;
import java.util.stream.Collectors;
import com.example.student_management.Entities.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class StudentRepository {

    private static Map<String, Student> studentStorage = new HashMap<>();

    public Student loadStudent(String studentId) {

        return studentStorage.getOrDefault(studentId, null);
    }

    public List<Student> listStudents() {

        return studentStorage.values().stream().collect(Collectors.toList());
    }

    public void saveStudent(Student student) {
        String id = student.getId();
        if(!studentStorage.containsKey(id)){
            studentStorage.put(student.getId(), student);
        }
    }
    public void createStudents(Student student) {
        String id = student.getId();
        if (!studentStorage.containsKey(id)){
            studentStorage.put(id, student);
        }
    }

    public void deleteStudent(String studentId) {
        if (studentStorage.containsKey(studentId)){
            studentStorage.remove(studentId);
        }
    }
}
