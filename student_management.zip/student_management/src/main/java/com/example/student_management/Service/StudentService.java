package com.example.student_management.Service;
import com.example.student_management.Entities.Student;
import com.example.student_management.Exceptions.ResourceNotFoundException;
import com.example.student_management.Infrastructure.StudentRepository;
import com.example.student_management.Infrastructure.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.student_management.Entities.Teacher;
import java.util.List;
@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepo;
    @Autowired
    private TeacherService teacherService;

    // List all students' profile info
    public List<Student> listAllStudents() {

        return studentRepo.listStudents();
    }

    // Get one student's profile by id
    public Student getStudentById(String id) {

        return studentRepo.loadStudent(id);
    }

    // Create a new student
    public void createStudent(Student student) {
        studentRepo.createStudents(student);
    }

    public Student updateStudent(String id, Student studentDetails) {
        Student student = studentRepo.loadStudent(id);
        if (student == null) {
            throw new ResourceNotFoundException("Student not found for this id :: " + id);
        }
        student.setName(studentDetails.getName());
        student.setAge(studentDetails.getAge());
        student.setAddress(studentDetails.getAddress());
        student.setEmail(studentDetails.getEmail());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        studentRepo.saveStudent(student);
        return student;
    }

    public void deleteStudent(String id) {

        studentRepo.deleteStudent(id);
    }
    public void signupStudentWithTeacher(String studentId, String teacherId) {
//          teacherService.addStudentToTeacher(teacherId, studentId);
        Student student = getStudentById(studentId);
        Teacher oldTeacher = student.getTeacher();
        if (oldTeacher != null) {
            teacherService.removeStudentFromTeacher(oldTeacher.getId(), studentId);
        }
        teacherService.addStudentToTeacher(teacherId, studentId);
    }

    public void removeStudentTeacherRelation(String studentId) {
//        Student student = getStudentById(studentId);
//        student.setTeacher(null);
//        studentRepo.saveStudent(student);
        Student student = getStudentById(studentId);
        if (student.getTeacher() != null) {
            String teacherId = student.getTeacher().getId();
            teacherService.removeStudentFromTeacher(teacherId, studentId);
        }
    }
}