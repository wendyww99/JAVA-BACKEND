package com.example.student_management.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.student_management.Service.StudentService;
import com.example.student_management.Entities.Student;
import java.util.List;
import java.util.Optional;

@RestController
public class StudentController {

    @Autowired
    private StudentService studentService = new StudentService();
    @GetMapping("/students")
    public List<Student> listAllStudents() {
        return studentService.listAllStudents();
    }

    @GetMapping(value = "/students/{id}")
    public Optional<Student> getStudentById(@PathVariable("id") String id) {
        return Optional.ofNullable(studentService.getStudentById(id));
    }

    @PostMapping(value = "/students")
    public void create(@RequestBody Student student) {
        studentService.createStudent(student);
    }

    @PutMapping("/students/{id}")
    public void updateStudent(@PathVariable("id") String id,@RequestBody Student studentDetails) {
        studentService.updateStudent(id, studentDetails);
    }

    @DeleteMapping("/students/{id}")
    public void deleteStudent(@PathVariable("id") String id) {
        studentService.deleteStudent(id);
    }
}
