package com.example.student_management.Controller;
import com.example.student_management.Entities.Student;
import com.example.student_management.Entities.Teacher;
import com.example.student_management.Service.StudentService;
import com.example.student_management.Service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Set;
@RestController
@RequestMapping("/signup")
public class SignupController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private TeacherService teacherService;

    @PostMapping("/buildSignup")
    public void signupStudentWithTeacher(@RequestParam String studentId, @RequestParam String teacherId) {
        studentService.signupStudentWithTeacher(studentId, teacherId);
    }

    @PutMapping("/updateSignup")
    public void updateStudentWithTeacher(@RequestParam String studentId, @RequestParam String teacherId) {
        studentService.signupStudentWithTeacher(studentId, teacherId);
    }

    @DeleteMapping("/deleteSignup")
    public void deleteStudentTeacherConnection(@RequestParam String studentId) {
        studentService.removeStudentTeacherRelation(studentId);
    }
    @GetMapping("/teacher/{teacherId}/students")
    public Set<Student> getStudentsByTeacherId(@PathVariable String teacherId) {
        Teacher teacher = teacherService.getTeacherById(teacherId);
        return teacher.getStudents();
    }
}
