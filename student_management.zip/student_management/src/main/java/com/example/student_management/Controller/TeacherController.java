package com.example.student_management.Controller;

import com.example.student_management.Entities.Teacher;
import com.example.student_management.Service.TeacherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/teachers")
public class TeacherController {

    @Autowired
    private TeacherService teacherService;

    @PostMapping
    public Teacher createTeacher(@RequestBody Teacher teacher) {

        return teacherService.createTeacher(teacher);
    }

    @GetMapping("/{id}")
    public Teacher getTeacherById(@PathVariable("id") String id) {

        return teacherService.getTeacherById(id);
    }

    @GetMapping
    public List<Teacher> getAllTeachers() {

        return teacherService.getAllTeachers();
    }

    @DeleteMapping("/{id}")
    public void deleteTeacher(@PathVariable("id") String id) {

        teacherService.deleteTeacher(id);
    }
}
