package com.example.student_management.Service;
import com.example.student_management.Entities.Teacher;
import com.example.student_management.Entities.Student;
import com.example.student_management.Exceptions.ResourceNotFoundException;
import com.example.student_management.Infrastructure.StudentRepository;
import com.example.student_management.Infrastructure.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class TeacherService {
    @Autowired
    private TeacherRepository teacherRepo;
    @Autowired
    private StudentRepository studentRepo;

    public Teacher createTeacher(Teacher teacher) {
        teacherRepo.saveTeacher(teacher);
        return teacher;
    }

    public Teacher getTeacherById(String id) {
        Teacher teacher = teacherRepo.loadTeacher(id);
        if (teacher == null) {
            throw new ResourceNotFoundException("Teacher not found for this id :: " + id);
        }
        return teacher;
    }

    public List<Teacher> getAllTeachers() {

        return teacherRepo.listTeachers();
    }
    public void updateTeacher(String id, Teacher teacherDetails) {
        Teacher teacher = getTeacherById(id);
        teacher.setName(teacherDetails.getName());
        teacher.setSubject(teacherDetails.getSubject());
        teacherRepo.saveTeacher(teacher);
    }

    public void deleteTeacher(String id) {

        teacherRepo.deleteTeacher(id);
    }
    public void addStudentToTeacher(String teacherId, String studentId) {
        Teacher teacher = getTeacherById(teacherId);
        Student student = studentRepo.loadStudent(studentId);
        teacher.getStudents().add(student);
        student.setTeacher(teacher);
        teacherRepo.saveTeacher(teacher);
        studentRepo.saveStudent(student);
    }

    public void removeStudentFromTeacher(String teacherId, String studentId) {
        Teacher teacher = getTeacherById(teacherId);
        Student student = studentRepo.loadStudent(studentId);
        teacher.getStudents().remove(student);
        student.setTeacher(null);
        teacherRepo.saveTeacher(teacher);
        studentRepo.saveStudent(student);
    }
}
