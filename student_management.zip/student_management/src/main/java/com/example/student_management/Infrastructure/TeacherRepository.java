package com.example.student_management.Infrastructure;

import com.example.student_management.Entities.Teacher;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class TeacherRepository {

    private static final Map<String, Teacher> teacherStorage = new HashMap<>();

    public Teacher loadTeacher(String teacherId) {
        return teacherStorage.getOrDefault(teacherId, null);
    }

    public List<Teacher> listTeachers() {
        return new ArrayList<>(teacherStorage.values());
    }

    public void saveTeacher(Teacher teacher) {
        String id = teacher.getId();
        if(!teacherStorage.containsKey(id)){
            teacherStorage.put(teacher.getId(), teacher);
        }
    }
    public void deleteTeacher(String teacherId) {
        teacherStorage.remove(teacherId);
    }
}
