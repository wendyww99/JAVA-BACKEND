package com.example.student_management.Service;

import com.example.student_management.Entity.Student;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class StudentService {
    private Map<String, Student> studentMap = new HashMap<>();

    public Student getStudentById(String id) {
        return studentMap.get(id);
    }

    public Map<String, Student> getAllStudents() {
        return studentMap;
    }

    public Student createStudent(Student student) {
        studentMap.put(student.getId(), student);
        return student;
    }

    public Student updateStudent(String id, Student student) {
        if (studentMap.containsKey(id)) {
            student.setId(id);
            studentMap.put(id, student);
            return student;
        }
        return null;
    }

    public boolean deleteStudent(String id) {
        return studentMap.remove(id) != null;
    }
}
